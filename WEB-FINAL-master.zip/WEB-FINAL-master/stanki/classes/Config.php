<?php

abstract class Config
{
    const HOST = 'localhost';
    const DB_NAME = 'stanki';
    const DB_USER = 'root';
    const DB_PASSWORD = '';
}