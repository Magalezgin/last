<?php
//require_once 'auth.php';
require_once 'template/header.php';
require_once 'template/footer.php';